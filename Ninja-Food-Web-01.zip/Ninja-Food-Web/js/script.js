$(document).ready(function(){
	$(".toggler").on("click", function(){
		$(".wrapper-1 nav ul.links").toggleClass("active");
		$(".toggler").toggleClass("active");
	});

	$('.load-more').on('click', function(){
		$(".more-food").toggleClass("more");
		$(".load-more a").innerHTML = "less";
	});
});
